"""NEW continuation coordinator, not a historical entry point. No retry or lock deletion.
Uses original run_phase13e.watch, study_worker.py and select_models.run unchanged.
"""
from pathlib import Path
import collections,datetime,hashlib,importlib.util,json,math,os,shutil,subprocess,sys,time,traceback
B=Path(__file__).resolve().parent
ROOT=B.parent;W=ROOT/'REPRO_ORIGINALS_20260921';K=W/'13E/source'
OLD=ROOT/'MAC_REPRODUCTION_20260921T180412Z'
AUDIT=OLD/'STOPPED_AUDIT_20260921T185714_145736Z'
CTRL=Path('/Users/fahad/Downloads/BRACE_Original_Reproduction_Controller')
PY=ROOT/'BRACE-Phase13C-20260912/.venv/bin/python'
THREADS=dict(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',NUMBA_NUM_THREADS='1',MPLBACKEND='Agg')
os.environ.update(THREADS)
os.environ.update(MPLCONFIGDIR=str(B/'cache/matplotlib'),XDG_CACHE_HOME=str(B/'cache'),NUMBA_CACHE_DIR=str(B/'cache/numba'))
sys.path.insert(0,str(K))
from study_io import read,write,verify,sha,load_role,job_specs
from run_phase13e import watch

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def require(ok,msg):
 if not ok:raise RuntimeError(msg)
def load_controller():
 spec=importlib.util.spec_from_file_location('original_controller',CTRL/'reproduce.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
report={'coordinator':'new continuation coordinator; original scientific functions unchanged','created_utc':utc(),'pid':os.getpid(),'historical_session':str(OLD),'output':str(B),'status':'preflight','new_job_executions':[],'stages':[],'adopted_count':0,'planned_new_count':67,'selection_invocations':0,'test_uses_historical_parent':True,'noise_uses_historical_parent':True,'new_archives_passed_to_historical_runners':False}
original_snapshot={}
def persist():write(B/'CONTINUATION_REPORT.json',report)
def snapshot(root):
 result={}
 for p in root.rglob('*'):
  require('old' not in p.parts and not p.is_symlink(),'Unsafe path in prior output')
  if p.is_file():result[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return result

def validate_scores(path,spec,queries,expected_y,jr):
 statuses=collections.Counter();errors=[];count=0
 with path.open() as f:
  for index,line in enumerate(f):
   value=json.loads(line);require(index<len(queries),'Too many score rows')
   row=queries[index]
   expected={k:row[k] for k in ['source','cascade_id','group_id','window_s']}
   expected.update(index=index,future_count=int(expected_y[index]),n_prefix=int(row['n_prefix']))
   require(all(value.get(k)==v for k,v in expected.items()),'Score identity mismatch '+spec['job_id']+':'+str(index))
   statuses[value['status']]+=1;count+=1
   if value['status']!='ok':errors.append({k:value[k] for k in ['index','cascade_id','window_s','status','error']})
 require(count==6000,'Incomplete score file '+spec['job_id'])
 require(set(statuses)<={'ok','score_failure','prediction_failure'},'Unknown score status')
 require(statuses['ok']==jr['score_successes'] and statuses['score_failure']==jr['score_failures'] and statuses['prediction_failure']==jr['prediction_failure_rows'],'Score count mismatch')
 require(jr['score_attempts']==statuses['ok']+statuses['score_failure'],'Attempt mismatch')
 require(errors==read(path.parent/'FAILURES.json'),'Failure identity mismatch')
 return {'readable_rows':count,'identity_and_window_alignment':True,'statuses':dict(statuses),'failure_records_match':True}

def main():
 global original_snapshot
 persist();start_mono=time.monotonic()
 cfg=read(K/'CONFIG.json');specs=read(K/'JOBS.json')
 # Conservative previous consumption includes idle time up to the completed stop audit.
 began=read(OLD/'train/run/STARTED.json')['time']
 bound=datetime.datetime.fromisoformat(read(AUDIT/'JOB_COMPLETENESS.json')['summary']['audit_created_utc']).timestamp()
 consumed=math.ceil(bound-began);remaining=cfg['budget']['global_seconds']-consumed
 budget={'original_seconds':cfg['budget']['global_seconds'],'previous_started_epoch':began,'previous_upper_bound_end_utc':datetime.datetime.fromtimestamp(bound,datetime.timezone.utc).isoformat(),'previous_consumption_upper_bound_seconds':consumed,'remaining_seconds':remaining,'uncertainty':'Exact stop-signal time unavailable; audit creation is a conservative upper bound. User waiting time after that audit is excluded.','new_budget_clock_start_utc':utc(),'new_budget_includes':'continuation preflight, adoption verification/copy, all new workers, selection/review before test','original_worker_limits':cfg['budget']}
 write(B/'BUDGET_AUDIT.json',budget);require(remaining>0,'No provable positive training budget');deadline=start_mono+remaining
 controller=load_controller()
 cm=read(CTRL/'CONTROLLER_MANIFEST.json');verify(CTRL,cm)
 env=controller.environment(W);write(B/'ENVIRONMENT_CHECK.json',env);require(env['passed'],'Historical environment mismatch')
 require(Path(sys.executable).resolve()==PY.resolve(),'Wrong Python interpreter')
 verified=controller.verify_tree(W)
 verify(K,read(K/'EXPERIMENT_FREEZE.json'));verify(K,read(K/'MANIFEST.json'))
 require(specs==job_specs(cfg) and len(specs)==154,'Schedule mismatch')
 archives=[]
 for item in read(CTRL/'DISTRIBUTION_INDEX.json')['payloads']:
  p=ROOT/'ORIGINALS_EXPORT_20260914T074651Z'/item['archive'];h=sha(p)
  require(p.stat().st_size==item['bytes'] and h==item['sha256'],'Original archive mismatch')
  archives.append({'path':str(p),'bytes':p.stat().st_size,'sha256':h,'matches_index':True})
 # Verify all previously audited evidence before trusting adoption records.
 prior_evidence=read(AUDIT/'EVIDENCE_MANIFEST.json')
 for value in prior_evidence.values():
  p=Path(value['source']);require(p.stat().st_size==value['bytes'] and sha(p)==value['sha256'],'Stopped evidence changed: '+str(p))
 original_snapshot=snapshot(OLD/'train');write(B/'PRIOR_TRAIN_SNAPSHOT.json',original_snapshot)
 write(B/'INPUT_VERIFICATION.json',{'verified_restored_file_records':verified,'controller_manifest_entries':len(cm),'original_archives':archives,'schedule_sha256':sha(K/'JOBS.json'),'prior_evidence_verified':len(prior_evidence),'no_live_processes_preflight':'Operator ps inspection before coordinator launch found only inspection commands, no experimental workers','process_check_provenance':'Tool result in current conversation; not inferred from stale SESSION_STATE'})
 run=B/'train_aggregate';(run/'jobs').mkdir(parents=True,exist_ok=False)
 recorded={r['path']:r for r in read(AUDIT/'LARGE_OUTPUT_SHA256.json')}
 reference_manifest=read(W/'13E/MANIFEST.json')
 cache={s:load_role(K,s,'VALIDATION',cfg['validation_roots_per_source']) for s in cfg['sources']}
 adopted=[];pending=[]
 for spec in specs:
  jid=spec['job_id'];old=OLD/'train/run/jobs'/jid
  if not old.exists():
   require(not (old.parent/(jid+'.log')).exists(),'Prior trace for supposedly unstarted job '+jid)
   pending.append(spec);continue
  jr=read(old/'JOB_REPORT.json');require(all(jr.get(k)==v for k,v in spec.items()),'Adopted spec mismatch')
  historical=read(W/'13E/run/jobs'/jid/'JOB_REPORT.json')
  require({k:v for k,v in jr.items() if k not in {'fit_seconds','prediction_scoring_seconds','total_seconds'}}=={k:v for k,v in historical.items() if k not in {'fit_seconds','prediction_scoring_seconds','total_seconds'}},'Adopted scientific report mismatch')
  meta=read(old/'MODEL_METADATA.json');require(meta==jr['model'],'Model metadata mismatch')
  require(meta==read(W/'13E/run/jobs'/jid/'MODEL_METADATA.json'),'Historical metadata mismatch')
  fit=old/'FIT_COMPONENTS.json'
  require((read(fit)['calls'] if fit.exists() else 0)==jr['component_fit_calls'],'Fit-component count mismatch')
  if fit.exists():
   ref=read(W/'13E/run/jobs'/jid/'FIT_COMPONENTS.json')
   require({k:v for k,v in read(fit).items() if k!='time'}=={k:v for k,v in ref.items() if k!='time'},'Fit-component identity mismatch')
  hrows=[]
  for name in ['MODEL.joblib','SCORES.jsonl']:
   p=old/name;h=sha(p);size=p.stat().st_size;rec=recorded[str(p)];ref=reference_manifest['run/jobs/'+jid+'/'+name]
   require(h==rec['sha256']==ref['sha256'] and size==rec['bytes']==ref['bytes'],'Adoption byte mismatch '+str(p))
   if name=='MODEL.joblib':require(h==jr['model_sha256'] and size==jr['model_bytes'],'Model report identity mismatch')
   hrows.append({'name':name,'bytes':size,'sha256':h,'matches_stop_audit_and_historical_manifest':True})
  scores=validate_scores(old/'SCORES.jsonl',spec,*cache[spec['source']],jr)
  dest=run/'jobs'/jid;shutil.copytree(old,dest,copy_function=shutil.copy2)
  for p in old.iterdir():
   require(p.is_file() and not p.is_symlink(),'Unexpected job directory member')
   copy=dest/p.name;require(sha(p)==sha(copy) and p.stat().st_size==copy.stat().st_size and p.stat().st_ino!=copy.stat().st_ino,'Copy not independent or differs')
  log=old.parent/(jid+'.log')
  if log.exists():shutil.copy2(log,dest.parent/log.name)
  pr=old/'PROCESS_REPORT.json'
  if pr.exists():require(read(pr)['returncode']==0 and not read(pr)['stop_reason'],'Unsuccessful adopted process')
  else:require(jid=='weibo__qrf__c2__I0__s20260913','Unexpected missing process report')
  adopted.append({'job_id':jid,'adoption_status':'completed_with_process_report' if pr.exists() else 'worker_report_present_exit_unrecorded','process_report_preserved_absent':not pr.exists(),'file_checks':hrows,'scores':scores,'metadata_and_fit_components_match':True,'independent_copy_bytes_match':True,'eligible_preserved':jr['eligible']})
 require(len(adopted)==87 and len(pending)==67,'Unexpected adoption/pending counts')
 write(B/'ADOPTION_AUDIT.json',{'status':'passed_integrity_and_completeness','adopted_count':87,'pending_count':67,'adopted':adopted,'no_returncode_or_exit_time_fabricated':True})
 write(B/'REMAINING_JOBS.json',pending);report['adopted_count']=87;report['status']='executing_remaining_jobs';persist()
 print('ADOPTION COMPLETE: 87; NEW JOBS: 67; REMAINING BUDGET',round(deadline-time.monotonic(),1),flush=True)
 for i,spec in enumerate(pending,1):
  jid=spec['job_id'];target=run/'jobs'/jid
  require(not target.exists(),'Target already exists; no retry')
  if time.monotonic()>=deadline:
   target.mkdir();write(target/'JOB_REPORT.json',dict(spec,status='not_attempted_global_budget',eligible=False,component_fit_calls=0));continue
  cmd=[sys.executable,str(K/'study_worker.py'),'--kit',str(K),'--out',str(target),'--job',jid]
  entry={'job_id':jid,'argv':cmd,'cwd':str(K),'environment':THREADS,'start_utc':utc(),'budget_remaining_at_start':deadline-time.monotonic()}
  report['new_job_executions'].append(entry);persist();print('NEW JOB',i,'OF',len(pending),jid,flush=True)
  pr=watch(K/'study_worker.py',['--kit',K,'--out',target,'--job',jid],run/'jobs'/(jid+'.log'),target/'BOOT_READY.json',cfg['budget']['job_initialization_seconds'],cfg['budget']['job_execution_seconds'],deadline)
  entry.update(end_utc=utc(),process=pr);target.mkdir(parents=True,exist_ok=True);write(target/'PROCESS_REPORT.json',pr)
  if not (target/'JOB_REPORT.json').exists():
   r=read(target/'PROGRESS.json') if (target/'PROGRESS.json').exists() else dict(spec)
   components=read(target/'FIT_COMPONENTS.json')['calls'] if (target/'FIT_COMPONENTS.json').exists() else 0
   r.update(status='interrupted_worker_preserved',eligible=False,component_fit_calls=components,counts_are_lower_bounds=True,process=pr);write(target/'JOB_REPORT.json',r)
  if pr['returncode']!=0:
   r=read(target/'JOB_REPORT.json');r.update(eligible=False,process_failed=True);write(target/'JOB_REPORT.json',r)
  persist()
 require(all((run/'jobs'/s['job_id']/'JOB_REPORT.json').is_file() for s in specs),'Missing job report')
 require(time.monotonic()<deadline,'Training budget exhausted before selection')
 report['status']='selecting_once';report['selection_invocations']=1;persist()
 from select_models import run as select
 report['selection']=select(K,run)
 comparisons={}
 for name in ['CANDIDATE_TABLE.json','SELECTION_REPORT.json','MODEL_LOCK.json','VALIDATION_CONTRASTS.json']:
  a=read(W/'13E/run'/name);b=read(run/name)
  try:controller.compare(a,b,name);numeric=True;error=None
  except Exception as e:numeric=False;error=str(e)
  comparisons[name]={'byte_equal':sha(W/'13E/run'/name)==sha(run/name),'declared_tolerance_match':numeric,'first_error':error,'historical_sha256':sha(W/'13E/run'/name),'new_sha256':sha(run/name)}
 report['selection_comparisons']=comparisons;write(B/'SELECTION_COMPARISON.json',comparisons)
 lock=read(run/'MODEL_LOCK.json');oldlock=read(W/'13E/run/MODEL_LOCK.json');original_models={m['job_id']:m for f in oldlock['models'] for m in f.get('models',[])}
 identity=[]
 for f in lock['models']:
  for m in f.get('models',[]):
   p=run/m['path'];actual=sha(p);ref=original_models.get(m['job_id'],{})
   identity.append({'job_id':m['job_id'],'sha256':actual,'own_lock_matches':actual==m['sha256'],'historical_model_matches':actual==ref.get('sha256'),'bytes':p.stat().st_size})
 bridge=len(identity)==40 and {r['job_id'] for r in identity}==set(original_models) and all(r['own_lock_matches'] and r['historical_model_matches'] for r in identity)
 write(B/'SELECTED_MODEL_IDENTITY.json',{'models':identity,'byte_identity_bridge':bridge,'new_archives_passed_to_old_runners':False});report['byte_identity_bridge']=bridge
 completed=all(read(run/'jobs'/s['job_id']/'JOB_REPORT.json').get('validation_forecasts_returned')==6000 and not read(run/'jobs'/s['job_id']/'JOB_REPORT.json').get('counts_are_lower_bounds',False) for s in specs)
 report['training_complete_reports']=completed
 report['training_budget_elapsed_seconds']=time.monotonic()-start_mono;report['training_budget_remaining_seconds']=deadline-time.monotonic();persist()
 require(completed,'Training incomplete: do not start later stages')
 require(time.monotonic()<deadline,'Budget exhausted during selection/review')
 report['status']='training_completed_reviewed';persist()
 # Independent historical-parent replays; each invoked once, never retried.
 for stage in ['test','noise']:
  out=B/stage;argv=[sys.executable,'-B',str(CTRL/'reproduce.py'),stage,'--work',str(W),'--out',str(out)]
  item={'stage':stage,'argv':argv,'cwd':str(ROOT),'start_utc':utc()};report['stages'].append(item);report['status']='running_'+stage;persist()
  print('START',stage,flush=True)
  with (B/(stage+'.console.log')).open('x') as f:p=subprocess.run(argv,cwd=ROOT,env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT)
  item.update(returncode=p.returncode,end_utc=utc())
  if (out/'RUN_REPORT.json').exists():item['run_report']=read(out/'RUN_REPORT.json')
  persist();print('END',stage,p.returncode,flush=True)
 report['status']='stages_finished_requires_final_audit'

try:main()
except BaseException as e:
 report.update(status='blocked_or_interrupted_preserved',error=type(e).__name__+': '+str(e),traceback=traceback.format_exc());print(report['error'],flush=True)
finally:
 try:
  if original_snapshot:report['prior_train_unchanged']=snapshot(OLD/'train')==original_snapshot
  report['source_after']=verify(K,read(K/'EXPERIMENT_FREEZE.json'))
 except Exception as e:report['integrity_verification_error']=str(e)
 report['end_utc']=utc();persist();print('CONTINUATION STATUS',report['status'],flush=True)
