# Phase 14B supplementary noise-control results

These analyses follow the observed Phase13F results. Original claims and failures remain unchanged.

| Source | Family | Contrast | Delta CRPS | Adjusted interval |
| --- | --- | --- | ---: | --- |
| weibo | hurdle | noise_minus_I0 | -0.001998 | [-0.035697, 0.029942] |
| weibo | hurdle | I1_minus_noise | -2.837752 | [-5.212433, -1.049872] |
| weibo | qrf | noise_minus_I0 | 0.953466 | [-1.255420, 4.802810] |
| weibo | qrf | I1_minus_noise | -5.303650 | [-10.531859, -1.905135] |
| weibo | ngboost | noise_minus_I0 | 0.033271 | [-0.036429, 0.079690] |
| weibo | ngboost | I1_minus_noise | -0.798742 | [-1.457261, -0.274438] |
| seismic | hurdle | noise_minus_I0 | 0.026735 | [-0.002406, 0.055985] |
| seismic | hurdle | I1_minus_noise | -7.040615 | [-10.573006, -4.832723] |
| seismic | qrf | noise_minus_I0 | -0.215576 | [-0.515268, 0.212376] |
| seismic | qrf | I1_minus_noise | -3.601548 | [-4.593946, -2.647896] |
| seismic | ngboost | noise_minus_I0 | 0.174242 | [-0.159860, 0.793027] |
| seismic | ngboost | I1_minus_noise | -3.256795 | [-4.144753, -2.392496] |

Negative deltas favor the first named procedure. Intervals are conditional on fixed models/noise realizations and grouping assumptions. Nonsignificance does not establish equality. A favorable noise result is retained; no replacement generator is requested.
