# Locked TEST results

Recorded archive growth with a root-relative 24-hour endpoint. Models, information sets and the six primary comparisons were locked before TEST.

| Source | Family | I0 CRPS | I1 CRPS | I1−I0 | Adjusted interval | Relative reduction |
|---|---|---:|---:|---:|---|---:|
| weibo | hurdle | 124.126230 | 121.286480 | -2.839750 | [-4.945411, -1.089673] | 2.29% |
| weibo | qrf | 100.990336 | 96.640152 | -4.350184 | [-7.577533, -0.396997] | 4.31% |
| weibo | ngboost | 111.249499 | 110.484028 | -0.765471 | [-1.393891, -0.272993] | 0.69% |
| seismic | hurdle | 52.035930 | 45.022050 | -7.013880 | [-10.133911, -4.956443] | 13.48% |
| seismic | qrf | 42.875398 | 39.058274 | -3.817124 | [-4.825852, -2.855497] | 8.90% |
| seismic | ngboost | 42.522490 | 39.439937 | -3.082553 | [-4.106720, -1.889757] | 7.25% |

Intervals use 10,000 shared paired resamples per source and Bonferroni adjustment over six absolute contrasts. Weibo resamples root-user clusters with root weighting; SEISMIC resamples roots. Seeds and windows stay within root.
These are bootstrap approximations conditional on fixed fitted models and the selected archive samples; unresolved event dependence, release selection and historical availability limit interpretation.
Relative reductions are point summaries; 2% is the predeclared practical reference. An interval crossing zero is not evidence of equivalence.
Incomplete seeded procedures and comparisons are withheld for the full sample, without deleting failed roots. No model was refitted or selected on TEST.
All complete reference procedures, per-window metrics, count calibration and the predeclared duplicate sensitivity are retained in the companion files. No causal containment or published CASPER/TiDeH superiority is established.
