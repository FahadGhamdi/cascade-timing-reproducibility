import argparse,importlib.metadata,os,signal,subprocess,sys,time,traceback
from pathlib import Path
from study_io import read,write,verify,sha,load_role,job_specs
KIT=Path(__file__).resolve().parent

def watch(script,args,log,ready,init_limit,execution_limit,global_deadline):
    env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
        MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',NUMBA_NUM_THREADS='1',MPLBACKEND='Agg')
    start=time.monotonic();began=None;heartbeat=start+20;reason=None
    with Path(log).open('w') as f:
        p=subprocess.Popen([sys.executable,str(script),*map(str,args)],cwd=KIT,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        while p.poll() is None:
            now=time.monotonic()
            if began is None and Path(ready).exists():began=now
            if now>=global_deadline:reason='global_budget'
            elif began is None and now-start>init_limit:reason='initialization_timeout'
            elif began is not None and now-began>execution_limit:reason='job_execution_timeout'
            if reason:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=3)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
                break
            if now>=heartbeat:
                print('RUNNING',Path(log).stem,'elapsed_seconds',round(now-start,1),'stage','execution' if began else 'initialization',flush=True)
                heartbeat=now+20
            time.sleep(.1)
    return dict(returncode=p.returncode,stop_reason=reason,wall_seconds=time.monotonic()-start)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--verify-only',action='store_true')
    a=ap.parse_args();out=Path(a.out).resolve()
    if out==KIT or KIT in out.parents:raise ValueError('output must be outside kit')
    out.mkdir(parents=True,exist_ok=False);cfg=read(KIT/'CONFIG.json');deadline=time.monotonic()+cfg['budget']['global_seconds']
    write(out/'STARTED.json',{'time':time.time(),'mode':'verification_only' if a.verify_only else 'full_selection','invocations':1})
    result={'status':'started','test_evaluations':0,'bootstrap':0,'casper_attempts':0}
    try:
        write(out/'SOURCE_BEFORE.json',verify(KIT,read(KIT/'EXPERIMENT_FREEZE.json')))
        if (KIT/'MANIFEST.json').exists():write(out/'KIT_BEFORE.json',verify(KIT,read(KIT/'MANIFEST.json')))
        versions={}
        for line in (KIT/'vendor/requirements.lock.txt').read_text().splitlines():
            if not line.strip() or line.startswith('#'):continue
            name,expected=line.split('==');versions[name]=importlib.metadata.version(name)
            if versions[name]!=expected:raise ValueError('dependency mismatch: '+name)
        if sys.version_info[:2]!=(3,12):raise ValueError('Python 3.12 required')
        write(out/'ENVIRONMENT.json',{'python':sys.version,'versions':versions})
        groups={};counts={}
        for s in cfg['sources']:
            groups[s]={};counts[s]={}
            for role,num in [('TRAIN',6000),('VALIDATION',2000)]:
                rows,y=load_role(KIT,s,role,num);groups[s][role]={r['group_id'] for r in rows};counts[s][role]={'roots':num,'windows':len(rows)}
            if groups[s]['TRAIN']&groups[s]['VALIDATION']:raise ValueError('role-group overlap')
        write(out/'DATA_CHECK.json',{'counts':counts,'group_disjoint':True,'test_read':False,'predictions':0})
        pre=watch(KIT/'preflight.py',[out/'preflight'],out/'PREFLIGHT.log',out/'preflight/BOOT_READY.json',180,60,deadline)
        write(out/'PREFLIGHT_PROCESS.json',pre)
        if pre['returncode']!=0 or not read(out/'preflight/TEST_REPORT.json')['passed']:raise ValueError('preflight failed')
        specs=read(KIT/'JOBS.json')
        if specs!=job_specs(cfg) or len(specs)!=cfg['expected_jobs']:raise ValueError('job schedule mismatch')
        if a.verify_only:
            result.update(status='verified_without_real_model_operations',real_fits=0,real_predictions=0,real_validation_scores=0)
        else:
            (out/'jobs').mkdir();write(out/'MODEL_PASS_STARTED.json',{'jobs':len(specs),'time':time.time()})
            for i,spec in enumerate(specs):
                jid=spec['job_id'];target=out/'jobs'/jid
                print('JOB',i+1,'OF',len(specs),jid,flush=True)
                if time.monotonic()>=deadline:
                    target.mkdir();write(target/'JOB_REPORT.json',dict(spec,status='not_attempted_global_budget',eligible=False,component_fit_calls=0))
                    continue
                pr=watch(KIT/'study_worker.py',['--kit',KIT,'--out',target,'--job',jid],out/'jobs'/(jid+'.log'),
                         target/'BOOT_READY.json',cfg['budget']['job_initialization_seconds'],cfg['budget']['job_execution_seconds'],deadline)
                target.mkdir(parents=True,exist_ok=True);write(target/'PROCESS_REPORT.json',pr)
                if not (target/'JOB_REPORT.json').exists():
                    r=read(target/'PROGRESS.json') if (target/'PROGRESS.json').exists() else dict(spec)
                    components=read(target/'FIT_COMPONENTS.json')['calls'] if (target/'FIT_COMPONENTS.json').exists() else 0
                    r.update(status='interrupted_worker_preserved',eligible=False,component_fit_calls=components,
                             counts_are_lower_bounds=True,process=pr)
                    write(target/'JOB_REPORT.json',r)
                # Reconcile a failed subprocess without treating its report as a valid candidate.
                if pr['returncode']!=0:
                    r=read(target/'JOB_REPORT.json');r.update(eligible=False,process_failed=True);write(target/'JOB_REPORT.json',r)
            from select_models import run
            result['selection']=run(KIT,out)
            result['status']='selection_completed_with_explicit_eligibility'
    except Exception as e:
        result.update(status='blocked',error=type(e).__name__+': '+str(e),traceback=traceback.format_exc());write(out/'BLOCKED.json',result)
    finally:
        try:result['source_after']=verify(KIT,read(KIT/'EXPERIMENT_FREEZE.json'))
        except Exception as e:result.update(status='integrity_failure',integrity_error=str(e))
        write(out/'PHASE13E_REPORT.json',result);print('PHASE13E_STATUS',result['status'],flush=True)
    return 0 if result['status'] in ['selection_completed_with_explicit_eligibility','verified_without_real_model_operations'] else 2

if __name__=='__main__':sys.exit(main())
