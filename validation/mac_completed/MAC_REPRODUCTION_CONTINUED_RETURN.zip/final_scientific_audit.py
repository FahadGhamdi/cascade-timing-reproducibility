"""Read-only scientific comparison. No model loading, training, or analysis reruns."""
from pathlib import Path
import csv, datetime, gzip, hashlib, itertools, json, math, sys
import numpy as np
BASE=Path(__file__).resolve().parent
WORK=BASE.parent/'REPRO_ORIGINALS_20260921'
OUT=BASE/'audit'
ATOL=1e-8; RTOL=1e-10
TIMING={'fit_seconds','prediction_scoring_seconds','total_seconds','seconds','wall_seconds','time','started_utc','end_utc'}
SERIAL={'model_sha256','model_bytes'}
MISSING=object()
def read(p): return json.loads(p.read_text())
def write(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def show(x):return '<MISSING>' if x is MISSING else json.dumps(x,ensure_ascii=False,sort_keys=True)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 state=read(BASE/'CONTINUATION_REPORT.json')
 if not state.get('end_utc'):raise RuntimeError('Scientific stages still running')
 OUT.mkdir(exist_ok=False)
 files=[]; jobrows=[]; modelrows=[]; summaries={}
 df=(OUT/'FIELD_DIFFERENCES.csv').open('x',newline='')
 writer=csv.writer(df);writer.writerow(['scope','field','category','historical','replayed','absolute_difference','within_tolerance'])
 def compare(a,b,scope,field='$',category='scientific',stats=None,lock=False):
  if stats is None:stats={'leaves':0,'exact_differences':0,'scientific_outside_tolerance':0,'timing_differences':0,'serialization_differences':0,'max_numeric_abs_difference':0.0}
  if a is not MISSING and b is not MISSING and isinstance(a,dict) and isinstance(b,dict):
   for k in sorted(a.keys()|b.keys()):
    cat=category
    if k in TIMING:cat='timing'
    if k in SERIAL or (lock and k in {'sha256','bytes'}):cat='serialization'
    if lock and k=='path':cat='path'
    compare(a.get(k,MISSING),b.get(k,MISSING),scope,field+'/'+k,cat,stats,lock)
   return stats
  if isinstance(a,list) and isinstance(b,list):
   for i,(x,y) in enumerate(itertools.zip_longest(a,b,fillvalue=MISSING)):
    compare(x,y,scope,field+'/'+str(i),category,stats,lock)
   return stats
  stats['leaves']+=1
  if a is not MISSING and b is not MISSING and type(a)==type(b) and a==b:return stats
  stats['exact_differences']+=1
  numeric=(isinstance(a,(int,float)) and not isinstance(a,bool) and isinstance(b,(int,float)) and not isinstance(b,bool))
  delta=abs(a-b) if numeric else ''
  same=math.isclose(a,b,rel_tol=RTOL,abs_tol=ATOL) if numeric else False
  if numeric and math.isfinite(delta):stats['max_numeric_abs_difference']=max(stats['max_numeric_abs_difference'],delta) if category=='scientific' else stats['max_numeric_abs_difference']
  if category=='scientific' and not same:stats['scientific_outside_tolerance']+=1
  elif category=='timing':stats['timing_differences']+=1
  elif category=='serialization':stats['serialization_differences']+=1
  writer.writerow([scope,field,category,show(a),show(b),delta,same])
  return stats
 def jsonfile(ref,new,scope,lock=False):
  rec={'scope':scope,'historical_path':str(ref),'replayed_path':str(new),'present':new.is_file() and ref.is_file()}
  if rec['present']:
   rec.update(compare(read(ref),read(new),scope,lock=lock))
   rec['historical_sha256']=sha(ref);rec['replayed_sha256']=sha(new)
   rec['passed_scientific_comparison']=rec['scientific_outside_tolerance']==0
  else:rec['passed_scientific_comparison']=False
  files.append(rec);return rec
 def streamfile(ref,new,scope):
  rec={'scope':scope,'historical_path':str(ref),'replayed_path':str(new),'present':ref.is_file() and new.is_file(),'rows':0,'differing_rows':0,'scientific_outside_tolerance':0}
  if rec['present'] and sha(ref)==sha(new):
   op=gzip.open if ref.suffix=='.gz' else open
   with op(new,'rt',newline='') as f:rec['rows']=sum(1 for _ in f)
   rec['byte_equal']=True;rec['passed_scientific_comparison']=True
   files.append(rec);return rec
  if rec['present']:
   op=gzip.open if ref.suffix=='.gz' else open
   csvmode=ref.name.endswith(('.csv','.csv.gz'))
   with op(ref,'rt',newline='') as f,op(new,'rt',newline='') as g:
    aa=csv.reader(f) if csvmode else f;bb=csv.reader(g) if csvmode else g
    for i,(a,b) in enumerate(itertools.zip_longest(aa,bb,fillvalue=MISSING)):
     rec['rows']+=1
     if a==b:continue
     rec['differing_rows']+=1
     if not csvmode:
      a=json.loads(a) if a is not MISSING else MISSING;b=json.loads(b) if b is not MISSING else MISSING
     else:
      def numeric_cells(row):
       if row is MISSING:return row
       result=[]
       for v in row:
        try:result.append(float(v))
        except ValueError:result.append(v)
       return result
      a=numeric_cells(a);b=numeric_cells(b)
     st=compare(a,b,scope,'$/row/'+str(i))
     rec['scientific_outside_tolerance']+=st['scientific_outside_tolerance']
   rec['passed_scientific_comparison']=rec['scientific_outside_tolerance']==0
  else:rec['passed_scientific_comparison']=False
  files.append(rec);return rec
 def npzfile(ref,new,scope):
  rec={'scope':scope,'present':ref.is_file() and new.is_file(),'arrays':[],'passed_scientific_comparison':False}
  if rec['present']:
   with np.load(ref,allow_pickle=False) as a,np.load(new,allow_pickle=False) as b:
    keys=set(a.files)==set(b.files);rec['keys_match']=keys
    for k in sorted(set(a.files)&set(b.files)):
     x,y=a[k],b[k];shape=x.shape==y.shape;numeric=np.issubdtype(x.dtype,np.number) and np.issubdtype(y.dtype,np.number)
     ok=shape and (np.allclose(x,y,atol=ATOL,rtol=RTOL,equal_nan=True) if numeric else np.array_equal(x,y))
     ar={'name':k,'shape_historical':list(x.shape),'shape_replayed':list(y.shape),'passed':bool(ok)}
     if numeric and shape:
      exact=np.equal(x,y)|(np.isnan(x)&np.isnan(y));close=np.isclose(x,y,atol=ATOL,rtol=RTOL,equal_nan=True)
      ar['different_elements']=int(np.count_nonzero(~exact));ar['outside_tolerance']=int(np.count_nonzero(~close))
      finite=np.isfinite(x)&np.isfinite(y);ar['max_abs_difference']=float(np.max(np.abs(x[finite]-y[finite]))) if np.any(finite) else None
      # Each aggregate array difference retained; no change to tolerance.
      for idx in np.argwhere(~exact):
       ix=tuple(idx); xv=x[ix].item();yv=y[ix].item()
       writer.writerow([scope,'$/'+k+'/'+','.join(map(str,idx)),'scientific',show(xv),show(yv),abs(xv-yv),bool(close[ix])])
     rec['arrays'].append(ar)
    rec['passed_scientific_comparison']=keys and all(r['passed'] for r in rec['arrays'])
  files.append(rec);return rec
 # Structural and aggregate comparisons, keeping timing and serialization distinct.
 configs=[('train','13E','jobs',154),('test','13F','jobs',40),('noise','14','noise_jobs',42)]
 for stage,refstage,folder,count in configs:
  root=BASE/'train_aggregate' if stage=='train' else BASE/stage/'run';refroot=WORK/refstage/'run'
  s={'expected_jobs':count,'observed_job_reports':0,'completed_processes':0,'failed_or_stopped_processes':[],'reference_job_set_match':False}
  names=[] if stage=='train' else ['PHASE'+refstage+'_REPORT.json']
  if stage=='train':names+=['CANDIDATE_TABLE.json','SELECTION_REPORT.json','MODEL_LOCK.json','VALIDATION_CONTRASTS.json']
  else:names+=['PARENT_VERIFICATION.json']
  start=len(files)
  for name in names:jsonfile(refroot/name,root/name,stage+'/'+name,lock=name=='MODEL_LOCK.json')
  refjobs={p.parent.name:p for p in (refroot/folder).glob('*/JOB_REPORT.json')}
  newjobs={p.parent.name:p for p in (root/folder).glob('*/JOB_REPORT.json')}
  s['observed_job_reports']=len(newjobs);s['reference_job_set_match']=set(refjobs)==set(newjobs)
  for jid in sorted(set(refjobs)|set(newjobs)):
   old=refroot/folder/jid;new=root/folder/jid
   result=jsonfile(old/'JOB_REPORT.json',new/'JOB_REPORT.json',stage+'/'+jid+'/JOB_REPORT.json')
   for n in ['FAILURES.json','MODEL_METADATA.json','FIT_COMPONENTS.json']:
    if (old/n).exists() or (new/n).exists():jsonfile(old/n,new/n,stage+'/'+jid+'/'+n)
   jr=read(new/'JOB_REPORT.json') if (new/'JOB_REPORT.json').exists() else {}
   pr=read(new/'PROCESS_REPORT.json') if (new/'PROCESS_REPORT.json').exists() else {}
   if pr.get('returncode')==0 and not pr.get('stop_reason'):s['completed_processes']+=1
   elif stage=='train' and jid=='weibo__qrf__c2__I0__s20260913' and jr.get('complete_scores') and not (new/'PROCESS_REPORT.json').exists():s['adopted_without_process_exit_record']=jid
   else:s['failed_or_stopped_processes'].append({'job_id':jid,'process_report':pr})
   jobrows.append({'stage':stage,'job_id':jid,'status':jr.get('status'),'eligible':jr.get('eligible'),'complete':jr.get('complete'),'seed':jr.get('seed'),'candidate':jr.get('candidate'),'score_attempts':jr.get('score_attempts'),'score_successes':jr.get('score_successes'),'score_failures':jr.get('score_failures'),'scientific_match':result['passed_scientific_comparison'],'returncode':pr.get('returncode'),'stop_reason':pr.get('stop_reason')})
   n='SCORES.jsonl.gz' if stage=='noise' else 'SCORES.jsonl'
   streamfile(old/n,new/n,stage+'/'+jid+'/'+n)
   if stage=='test':streamfile(old/'ROOT_SCORES.csv.gz',new/'ROOT_SCORES.csv.gz',stage+'/'+jid+'/ROOT_SCORES.csv.gz')
   model=new/'MODEL.joblib'
   if model.is_file():
    actual=sha(model);oldmodel=old/'MODEL.joblib'
    historical=sha(oldmodel) if oldmodel.is_file() else None
    modelrows.append({'stage':stage,'job_id':jid,'bytes':model.stat().st_size,'sha256':actual,'report_sha256':jr.get('model_sha256'),'matches_own_report':actual==jr.get('model_sha256'),'historical_sha256':historical,'historical_bytes_equal':actual==historical,'scientific_conclusion_from_hash_alone':False})
  s['all_compared_scientific_files_match']=all(f['passed_scientific_comparison'] for f in files[start:])
  s['all_jobs_accounted_including_adopted_exit_unrecorded']=s['reference_job_set_match'] and len(newjobs)==count and s['completed_processes']+int('adopted_without_process_exit_record' in s)==count
  summaries[stage]=s
  print('Audited',stage,flush=True)
 # Complete saved-score analysis comparisons, including the bootstrap distributions.
 primary=['PRIMARY_COMPARISONS.json','PROCEDURE_METRICS.json','CALIBRATION.json','DUPLICATE_SENSITIVITY.json','BOOTSTRAP_DESIGN.json','BOOTSTRAP_DELTAS.csv.gz','ROOT_PROCEDURE_SCORES.csv.gz']
 strata=['STRATA_RESULTS.json','CASE_METADATA.json','BOOTSTRAP_DESIGN.json','STRATA_BOOTSTRAP.npz','MSLE_SAVED_MEDIANS.csv','STRATUM_LEVELS.csv','EMPIRICAL_REFERENCES_BY_STRATUM.csv','PROCEDURE_LOSSES.npz']
 noise=['NOISE_COMPARISONS.json','NOISE_BOOTSTRAP.npz','NOISE_MATRIX_BINDINGS.json','NOISE_REALIZATION_SUMMARIES.csv','NOISE_PROCEDURE_LOSSES.npz','PROCEDURE_COMPLETENESS.json']
 groups=[('test/run/analysis','13F/run/analysis',primary),('noise/run/stage_a','14/run/stage_a',strata),('noise/run/stage_b','14/run/stage_b',noise)]
 for dest,ref,names in groups:
  for name in names:
   func=jsonfile if name.endswith('.json') else npzfile if name.endswith('.npz') else streamfile
   func(WORK/ref/name,BASE/dest/name,dest+'/'+name)
 # Explicit, reviewable candidate and selection-count table (including equal values).
 refcand=WORK/'13E/run/CANDIDATE_TABLE.json';newcand=BASE/'train_aggregate/CANDIDATE_TABLE.json'
 if newcand.exists():
  key=lambda r:(r['source'],r['family'],r['candidate'])
  aa={key(r):r for r in read(refcand)};bb={key(r):r for r in read(newcand)}
  with (OUT/'CANDIDATE_COMPARISON.csv').open('x',newline='') as f:
   cw=csv.writer(f);cw.writerow(['source','family','candidate','historical_eligible','replayed_eligible','historical_params','replayed_params','historical_selection_crps','replayed_selection_crps','absolute_crps_difference','job_ids_match','ineligible_job_ids_match'])
   for k in sorted(aa.keys()|bb.keys()):
    a=aa.get(k,{});b=bb.get(k,{});x=a.get('selection_crps');y=b.get('selection_crps')
    cw.writerow([*k,a.get('eligible'),b.get('eligible'),show(a.get('params')),show(b.get('params')),x,y,abs(x-y) if x is not None and y is not None else '',a.get('jobs')==b.get('jobs'),a.get('ineligible_jobs')==b.get('ineligible_jobs')])
 sel=BASE/'train_aggregate/SELECTION_REPORT.json'
 if sel.exists():
  a=read(WORK/'13E/run/SELECTION_REPORT.json');b=read(sel)
  with (OUT/'SELECTION_COUNTS.csv').open('x',newline='') as f:
   cw=csv.writer(f);cw.writerow(['field','historical','replayed','exact_match'])
   for k in sorted(a.keys()|b.keys()):cw.writerow([k,show(a.get(k)),show(b.get(k)),a.get(k)==b.get(k)])
 # Validate every selected model against the newly produced lock, without loading joblib.
 lock_path=BASE/'train_aggregate/MODEL_LOCK.json'; lockcheck=[]
 if lock_path.exists():
  for fam in read(lock_path)['models']:
   for m in fam['models']:
    p=BASE/'train_aggregate'/m['path']
    safe=p.resolve().is_relative_to(BASE/'train_aggregate') and not p.is_symlink()
    ok=safe and p.is_file() and p.stat().st_size==m['bytes'] and sha(p)==m['sha256']
    lockcheck.append({'job_id':m['job_id'],'matches_lock':ok})
 write(OUT/'SELECTED_MODEL_VERIFICATION.json',{'models':lockcheck,'expected_count':40,'passed':len(lockcheck)==40 and all(x['matches_lock'] for x in lockcheck)})
 write(OUT/'FILE_COMPARISONS.json',files);write(OUT/'SCIENTIFIC_SUMMARY.json',{'created_utc':utc(),'atol':ATOL,'rtol':RTOL,'numeric_json_csv_method':'math.isclose; unchanged controller tolerances','npz_method':'numpy.allclose; equal_nan=True; unchanged controller tolerances','timing_fields':sorted(TIMING),'serialization_fields':sorted(SERIAL),'model_lock_serialization_fields':['sha256','bytes'],'model_lock_path_field':'path (separately recorded; no evidence of scientific equivalence by itself)','stages':summaries,'new_archives_passed_to_historical_runners':False,'selected_model_identity_bridge_evidence':'../SELECTED_MODEL_IDENTITY.json'})
 for name,rows in [('JOB_COMPLETENESS.csv',jobrows),('MODEL_SERIALIZATION.csv',modelrows)]:
  with (OUT/name).open('x',newline='') as f:
   if rows:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 df.close()
 print(json.dumps(summaries,indent=2),flush=True)
if __name__=='__main__':main()
