"""Package existing evidence only; no experimental code execution."""
from pathlib import Path
import csv,datetime,hashlib,json,zipfile
B=Path(__file__).resolve().parent;ROOT=B.parent
OLD=ROOT/'MAC_REPRODUCTION_20260921T180412Z';W=ROOT/'REPRO_ORIGINALS_20260921'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 report=read(B/'CONTINUATION_REPORT.json');assert report.get('end_utc'),'Still running'
 d=B/'return_bundle';d.mkdir(exist_ok=False)
 def write(n,x):(d/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
 audit=read(B/'audit/SCIENTIFIC_SUMMARY.json');files=read(B/'audit/FILE_COMPARISONS.json')
 failed=[x for x in files if not x['passed_scientific_comparison']]
 budget=read(B/'BUDGET_AUDIT.json');identity=read(B/'SELECTED_MODEL_IDENTITY.json') if (B/'SELECTED_MODEL_IDENTITY.json').exists() else {}
 stagecounts={};large=[];markers=[]
 roots=[('train',B/'train_aggregate','jobs',154),('test',B/'test/run','jobs',40),('noise',B/'noise/run','noise_jobs',42)]
 for stage,root,jobs,expected in roots:
  entries=[read(p) for p in (root/jobs).glob('*/JOB_REPORT.json')]
  prs=[read(p) for p in (root/jobs).glob('*/PROCESS_REPORT.json')]
  counts={'expected_jobs':expected,'job_reports':len(entries),'process_exit_records':len(prs),'successful_process_exits':sum(p.get('returncode')==0 and not p.get('stop_reason') for p in prs),'complete_reports':sum(x.get('complete',False) for x in entries) if stage!='train' else None,'status_counts':{},'accounting':{k:sum(x.get(k,0) for x in entries) for k in ['component_fit_calls','score_attempts','score_successes','score_failures','prediction_failure_rows','test_forecasts_returned','predictions_returned','validation_forecasts_returned']}}
  for x in entries:counts['status_counts'][x['status']]=counts['status_counts'].get(x['status'],0)+1
  stagecounts[stage]=counts
  # Hash generated model/score/array products only, excluding parent copies and raw inputs.
  for p in root.rglob('*'):
   rel=p.relative_to(root)
   if not p.is_file() or 'parent13f' in rel.parts or 'preflight' in rel.parts:continue
   if p.suffix in {'.joblib','.npz'} or 'SCORES' in p.name or p.name.endswith('.csv.gz') or p.stat().st_size>=1000000:
    large.append({'stage':stage,'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'included_in_return':False})
   if any(s in p.name.upper() for s in ['LOCK','STARTED','FREEZE']):markers.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
 write('STAGE_COMPLETENESS.json',stagecounts);write('LARGE_OUTPUT_SHA256.json',large)
 write('COMPARISON_FAILURES.json',failed);write('LOCK_MARKERS.json',markers)
 actual={'coordinator_argv':[str(ROOT/'BRACE-Phase13C-20260912/.venv/bin/python'),'-B','-u',str(B/'continue_original_jobs.py')],'cwd':str(ROOT),'stdout_stderr':str(B/'continuation.console.log'),'jobs':report['new_job_executions'],'selection':{'function':'select_models.run','historical_source':str(W/'13E/source/select_models.py'),'kit':str(W/'13E/source'),'out':str(B/'train_aggregate'),'invocations':report['selection_invocations']},'test_and_noise':report['stages']}
 write('ACTUAL_COMMANDS.json',actual)
 training_match=(audit['stages']['train']['all_compared_scientific_files_match'] and report.get('training_complete_reports',False) and identity.get('byte_identity_bridge',False) and report.get('selection_comparisons',{}).get('MODEL_LOCK.json',{}).get('byte_equal',False) and report.get('training_budget_remaining_seconds',-1)>=0)
 test_match=all(f['passed_scientific_comparison'] for f in files if f['scope'].startswith('test/')) and stagecounts['test']['complete_reports']==40
 noise_match=all(f['passed_scientific_comparison'] for f in files if f['scope'].startswith('noise/')) and stagecounts['noise']['complete_reports']==42
 write('FINAL_CLAIMS.json',{'created_utc':now(),'training_154_reports_match_reference':training_match,'test_40_complete_and_compared':test_match,'noise_42_complete_and_compared':noise_match,'selected_models_byte_identity_bridge':identity.get('byte_identity_bridge',False),'new_archives_passed_to_historical_runners':False,'check_all_rerun':False,'prior_train_unchanged':report.get('prior_train_unchanged'),'scope_note':'A training result from 87 adopted + 67 new jobs; independent test/noise on locked historical parents. Identity bridge only if selected-model bytes are verified identical.','comparison_failures_count':len(failed)})
 def label(v):return 'مثبت بالمقارنة' if v else 'غير مثبت؛ راجع التقارير والفروق'
 tc=stagecounts['train'];te=stagecounts['test'];no=stagecounts['noise']
 md=f'''# استكمال إعادة الإنتاج على Mac

## النتيجة وحدودها

- التدريب المستكمل: **{label(training_match)}**.
- التقييم بالنماذج التاريخية، 40 مهمة: **{label(test_match)}**.
- ملاءمة الضجيج، 42 مهمة: **{label(noise_match)}**.
- تطابق بايتات النماذج المختارة مع الأصل: **{identity.get('byte_identity_bridge',False)}**.
- عدد مقارنات الملفات غير الناجحة/المفقودة: **{len(failed)}**؛ تفصيلها في COMPARISON_FAILURES.json.

هذه نتيجة مجمعة من جلستين: 87 مهمة موروثة فُحصت محليًا و67 مهمة كان مصرحًا ببدئها الآن. نقطة التنسيق continue_original_jobs.py جديدة، وتستدعي watch والعامل ودالة الاختيار الأصلية دون تعديل. لم يُستعمل train العام لإعادة154 مهمة.

## المسارات والأوامر

- المصادر المستعادة: `{W}`.
- التشغيل المتوقف المحفوظ: `{OLD}`.
- الاستكمال: `{B}`.
- Python التاريخي: `{ROOT}/BRACE-Phase13C-20260912/.venv/bin/python`.
- المتحكم: `/Users/fahad/Downloads/BRACE_Original_Reproduction_Controller/reproduce.py`.

الأوامر الفعلية لكل مهمة، cwd، متغيرات threads وأوقات البدء والنهاية ورموز الخروج في ACTUAL_COMMANDS.json وCONTINUATION_REPORT.json. فحص الحزم الـ33 وPython في ENVIRONMENT_CHECK.json. لم تُغيَّر الإصدارات أو البذور أو الحدود.

## اعتماد العمل السابق

قُرئت ملفات النماذج والدرجات للمهام87 وأعيد حساب SHA256 ومقارنتها بسجل التوقف وmanifest التاريخي. قُرئت6000 حالة لكل مهمة، وطوبقت الهويات والنوافذ والحالات والإخفاقات والتقارير وMODEL_METADATA وFIT_COMPONENTS. نُقلت نسخ مستقلة مع مقارنة البصمات؛ لا hard links.

المهمة weibo__qrf__c2__I0__s20260913 معتمدة بحالة worker_report_present_exit_unrecorded. غياب PROCESS_REPORT الأصلي محفوظ، ولم يُخترع رمز خروج أو توقيت. تفاصيلها ADOPTION_AUDIT.json.

## الميزانية

الحد الأصلي **{budget['original_seconds']} ثانية**. استُخدم حد محافظ للاستهلاك السابق **{budget['previous_consumption_upper_bound_seconds']} ثانية**، من STARTED إلى وقت إنشاء تدقيق التوقف. الرصيد المسموح **{budget['remaining_seconds']} ثانية**، وليس21600 ثانية جديدة. يتضمن العداد الجديد فحص الاعتماد والنسخ والعمل والاختيار والمراجعة. الانتظار اللاحق لتدقيق التوقف مستبعد.

زمن الاستكمال المحتسب حتى مراجعة التدريب: `{report.get('training_budget_elapsed_seconds')}` ثانية؛ الرصيد حينها `{report.get('training_budget_remaining_seconds')}`. حساب الحد وعدم يقين توقيت الإيقاف في BUDGET_AUDIT.json. لا إعادة محاولات تلقائية.

## اكتمال المراحل

| المجال | الدليل |
|---|---|
| raw preparation | لم يُعد؛ check-all السابق نجح، وأُعيد التحقق من بصمات مدخلاته. التقرير السابق مرفق وموسوم historical. |
| saved-score analyses | نتائج check-all السابقة فقط؛ لم يُعد check-all. التحليلات التابعة لـtest وnoise موثقة بسجلاتهما الحالية. |
| refitting | {tc['job_reports']} تقرير من154؛ حالات المهام: `{tc['status_counts']}`. {tc['process_exit_records']} سجل خروج؛ السجل الناقص هو المهمة87 المعتمدة بأدلتها. |
| frozen-model predictions | {te['job_reports']} تقرير من40؛ {te['complete_reports']} تقرير complete؛ محاولات الدرجات {te['accounting']['score_attempts']} والإخفاقات {te['accounting']['score_failures']}. |
| noise refitting | {no['job_reports']} تقرير من42؛ {no['complete_reports']} تقرير complete؛ استدعاءات مكونات الملاءمة {no['accounting']['component_fit_calls']} ومحاولات الدرجات {no['accounting']['score_attempts']}. |
| publication rendering | لم يُعد توليد رسوم الورقة أو ترجمة LaTeX؛ نجاح العرض السابق في check-all محفوظ. رسوم test وnoise، إن اكتملت، توثقها تقارير المراحل الحالية. |

CANDIDATE_TABLE وSELECTION_REPORT وMODEL_LOCK وVALIDATION_CONTRASTS الجديدة مرفقة، مع CSV للفروق والأعداد والمقارنات. فُصلت فروق التوقيت والتسلسل إلى ملفات نموذج عن الحقول العلمية. إخفاقات الدرجات محفوظة وتُقارن بالمرجع، ولا تُحذف لتغيير الأهلية.

## جسر الهوية والآباء التاريخيون

test استخدم أرشيف13E التاريخي، وnoise استخدم أرشيف13F التاريخي، وفق العقود المقفلة. **لم تمرر الأرشيفات الجديدة فعليًا إلى runners القديمة**. إذا كان SELECTED_MODEL_IDENTITY يثبت تطابق النماذج المختارة بايتًا، فهذا جسر هوية موثق إلى النماذج المستخدمة في التقييم؛ وإلا لا يثبت هذا التشغيل سلسلة تقييم للنماذج المعاد ملاءمتها، ويلزم تقييم مستقل دون تبديل الأقفال.

لم يُصطنع PHASE13E_REPORT تاريخي يوحي بانتهاء الجلسة المتوقفة طبيعيًا. CONTINUATION_REPORT يربط الجلستين. سلامة التشغيل السابق بعد الاستكمال: `{report.get('prior_train_unchanged')}`.

الحزمة أدلة صغيرة؛ النماذج والبيانات والدرجات الكبيرة مستبعدة، وبصماتها في LARGE_OUTPUT_SHA256.json. الأدلة والفروق والسجلات والأقفال محفوظة. لا رفع إلى خدمات خارجية.
'''
 (d/'SUMMARY_AR.md').write_text(md,encoding='utf-8')
 selected={}
 def add(p,n):
  if p.is_file():
   assert not p.is_symlink() and 'old' not in p.parts
   selected[n]=p
 for p in B.iterdir():
  if p.is_file() and p.suffix in {'.json','.py','.md','.log'}:add(p,p.name)
 for folder in ['audit','return_bundle']:
  for p in (B/folder).iterdir():
   if p.is_file():add(p,folder+'/'+p.name)
 for stage,root,jobs,_ in roots:
  for p in root.rglob('*'):
   rel=p.relative_to(root)
   if any(x in rel.parts for x in ['parent13f','models','noise_matrices']) or p.name=='CASE_METADATA.json':continue
   if p.is_file() and (p.suffix in {'.json','.log','.md','.txt'} or p.name=='EXECUTION.jsonl'):add(p,'evidence/'+stage+'/'+str(rel))
 for stage in ['test','noise']:
  for p in (B/stage).glob('*'):
   if p.is_file() and p.suffix in {'.json','.log'}:add(p,'evidence/'+stage+'/'+p.name)
 for name in ['check_all/RUN_REPORT.json','ENVIRONMENT_CHECK.json','SESSION_STATE.json']:
  add(OLD/name,'historical_previous/'+name)
 for name in ['SUMMARY_AR.md','STOP_RECORD.json','JOB_COMPLETENESS.json','PACKAGE_VERIFICATION.json']:
  add(OLD/'STOPPED_AUDIT_20260921T185714_145736Z'/name,'historical_previous/stopped_audit/'+name)
 for name in ['CONFIG.json','JOBS.json','EXPERIMENT_FREEZE.json','MANIFEST.json','vendor/requirements.lock.txt']:
  add(W/'13E/source'/name,'historical_contracts/13E/'+name)
 evidence={n:{'bytes':p.stat().st_size,'sha256':sha(p),'source':str(p)} for n,p in selected.items()}
 write('RETURN_MANIFEST.json',evidence);add(d/'RETURN_MANIFEST.json','RETURN_MANIFEST.json')
 zpath=B/'MAC_REPRODUCTION_CONTINUED_RETURN.zip'
 with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,p in sorted(selected.items()):z.write(p,n)
 with zipfile.ZipFile(zpath) as z:
  assert z.testzip() is None
  for n,p in selected.items():
   with z.open(n) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==sha(p),n
 verify={'status':'PASS','scope':'ZIP packaging integrity, not a blanket experimental claim','bytes':zpath.stat().st_size,'sha256':sha(zpath),'members':len(selected),'all_member_hashes_verified':True,'utc':now()}
 (B/'RETURN_PACKAGE_VERIFICATION.json').write_text(json.dumps(verify,indent=2)+'\n')
 print(json.dumps({'zip':str(zpath),'verification':verify,'claims':read(d/'FINAL_CLAIMS.json')},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
