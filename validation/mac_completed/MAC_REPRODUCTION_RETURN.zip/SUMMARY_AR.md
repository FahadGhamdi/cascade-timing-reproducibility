# تقرير التشغيل التجريبي المتوقف

**الحكم: إعادة التدريب غير مكتملة وغير مثبتة. التوقف يدوي استجابةً لتغيير طلب المستخدم، وليس حكمًا بفشل علمي شامل.**

## الأمر والمسارات

أمر التدريب الفعلي المسجل:
```sh
/Users/fahad/Documents/Research-Projects/RADIC/BRACE-Phase13C-20260912/.venv/bin/python -B /Users/fahad/Downloads/BRACE_Original_Reproduction_Controller/reproduce.py train --work /Users/fahad/Documents/Research-Projects/RADIC/REPRO_ORIGINALS_20260921 --out /Users/fahad/Documents/Research-Projects/RADIC/MAC_REPRODUCTION_20260921T180412Z/train
```

- مجلد العمل: `/Users/fahad/Documents/Research-Projects/RADIC`.
- المتحكم: `/Users/fahad/Downloads/BRACE_Original_Reproduction_Controller/reproduce.py`.
- المصادر العلمية المستعادة: `/Users/fahad/Documents/Research-Projects/RADIC/REPRO_ORIGINALS_20260921/13E/source`.
- Python التاريخي: `/Users/fahad/Documents/Research-Projects/RADIC/BRACE-Phase13C-20260912/.venv/bin/python`.
- الإخراج: `/Users/fahad/Documents/Research-Projects/RADIC/MAC_REPRODUCTION_20260921T180412Z/train/run`.
- الأمر المشرف وجميع أوامر المراحل وتوقيتها وبيئتها في `ACTUAL_COMMANDS.json` ونسخة `SESSION_STATE.json` الأصلية.

## ما اكتمل وما بقي

| المرحلة | النتيجة والأدلة |
|---|---|
| استعادة الأصول والبيئة | اكتمل restore؛ Python 3.12.14 وجميع الحزم الـ33 مطابقة في ENVIRONMENT_CHECK. |
| raw preparation | نجحت مطابقة 22 إدخالًا في check_all/RUN_REPORT.json. |
| saved-score analyses | نجحت المقارنات الأساسية والشرائح والضجيج والـbootstrap من الدرجات التاريخية المحفوظة. هذه ليست تنبؤات جديدة. |
| publication rendering | نجح التحقق من أدلة الورقة وإعادة توليد الأشكال والملخص الرسومي. لم تُجرَ ترجمة جديدة لملف LaTeX إلى PDF. |
| train / refitting | بدأت ملاءمة فعلية؛ اكتمل preflight (18 اختبارًا). التشغيل توقف قبل اكتمال جدول التدريب والاختيار النهائي. |
| frozen-model predictions / test | لم تبدأ المرحلة المستقلة test؛ لا يوجد إخراجها أو RUN_REPORT الخاص بها. |
| noise refitting | لم تبدأ مرحلة noise؛ تحليل الضجيج الناجح في check-all استخدم الدرجات القديمة فقط. |

فحص check-all وثّق مطابقة 2940 سجل ملف قبل التنفيذ وبعده. لا يُقدَّم هذا بوصفه فحصًا جديدًا بعد الإيقاف. تقاريره وسجلاته الأصلية مرفقة.

## اكتمال مهام التدريب

- الجدول الأصلي: **154 مهمة**.
- **86 مهمة** لها PROCESS_REPORT برمز خروج 0 ودون stop_reason.
- **مهمة واحدة إضافية**، `weibo__qrf__c2__I0__s20260913`، لها JOB_REPORT نهائي و`complete_scores=true` و6000 درجة ناجحة، لكن **لا يوجد PROCESS_REPORT**؛ لذلك لا نؤكد تسجيل خروجها بنجاح، ولا نصف نتائجها بأنها ملاءمة ناقصة.
- **67 مهمة لم تبدأ** وفق غياب مجلداتها وتقاريرها وسجل التسلسل.
- إجمالي JOB_REPORT المتاحة: **87**، منها **81 مؤهلة و6 غير مؤهلة محفوظة**. عدم الأهلية لا يعني تعطل العملية: العمليات الـ86 المسجلة خرجت برمز 0.
- بينها **77 مهمة لنماذج متعلّمة**، و**89 استدعاء ملاءمة مكوّن**. الأدلة: FIT_COMPONENTS وMODEL_METADATA وJOB_REPORT وبصمات ملفات MODEL.joblib؛ لم تُحمّل النماذج أثناء هذا التدقيق.
- محاولات تقييم VALIDATION: **522000**، نجحت **521984**، وفشلت عدديًا **16**.
- عدد المهام المثبت توقفها أثناء الملاءمة نفسها: **غير مثبت**؛ المتوقف يقينًا هو التشغيل المشرف. توجد مهمة واحدة بلا إثبات خروج مسجل، و67 غير مبدوءة.

التفصيل لكل مهمة من الـ154 في `JOB_COMPLETENESS.csv` و`JOB_COMPLETENESS.json`. مقارنة جزئية لتقارير المهام فقط في `PARTIAL_REPORT_COMPARISON.json`، مع فصل حقول التوقيت؛ لا تُثبت هذه المقارنة نجاح إعادة التدريب كاملة ولا سلسلة refit→test.

## سبب التوقف وآخر رسالة

أوقف المساعد التشغيل يدويًا عندما طلب المستخدم مهمة التقسيم فقط ومنع تشغيل التجارب. أُرسلت إشارات STOP ثم TERM ثم CONT إلى عمليات الإشراف المحددة لمنع انتقالها إلى test أو noise. انتهت جلسة المشرف برمز **143**. التفاصيل في `STOP_RECORD.json`، وهو سجل تدقيق لاحق مستند إلى المحادثة ونتائج الأدوات، وليس تقريرًا أصليًا مولّدًا من runner. التوقيت الدقيق لإشارة الإيقاف غير مسجل.

آخر سطر تنفيذ:
```text
JOB 87 OF 154 weibo__qrf__c2__I0__s20260913
```

آخر إخفاق درجات متاح، بحسب وقت تعديل ملف FAILURES وترتيب الإدخالات داخله:
```text
ScoreFailure: CRPS tail tolerance not attained within frozen grid
```
وظيفته: `weibo__hurdle__c2__I1__s20260913`. هذا إخفاق عددي محفوظ سبق الإيقاف، ولا يوجد دليل على أنه سبب الإيقاف. لا توجد رسالة خطأ قاتلة أو traceback في سجلات التجربة المتاحة. رسالة `kill ... no such process` تخص عاملًا كان قد انتهى، وليست خطأً علميًا.

بقيت `SESSION_STATE.json` تحمل `train: running` لأن الإنهاء بالإشارة سبق كتابة الحالة النهائية؛ حُفظت دون تعديل. فحص العمليات بعد الإيقاف وفي هذا التدقيق لم يجد عمليات التجربة المطابقة.

## التقارير الناقصة وحدود الاستنتاج

لا توجد `train/RUN_REPORT.json` أو `PHASE13E_REPORT.json` أو `CANDIDATE_TABLE.json` أو `SELECTION_REPORT.json` أو `MODEL_LOCK.json` جديدة نهائية. قائمة الوجود والغياب في `REPORT_AVAILABILITY.json`. لم نصطنع تقارير بديلة تحمل أسماء التقارير الأصلية المفقودة.

الأقفال التاريخية داخل `historical_contracts` مرجعية فقط؛ ليست نتيجة التدريب الجديد. حُفظت علامات STARTED وMODEL_PASS_STARTED وأقفال المصدر كما هي. لم يُحذف أو يُعدّل أي قفل أو إخراج، ولم تُستأنف تجربة أو يُنفّذ سكربت التدقيق السابق الذي كان ينتظر اكتمال التشغيل.

الحزمة لا تحتوي البيانات أو النماذج أو ملفات الدرجات الكبيرة. بصمات المخرجات الكبيرة المتاحة في `LARGE_OUTPUT_SHA256.json`. بصمات المصادر المرفقة في `EVIDENCE_MANIFEST.json`، ونتيجة التحقق من الحزمة بجوار ZIP. لم تُرفع الملفات إلى أي خدمة.
