# Phase 13E — selection results, no TEST evaluation

All displayed contrasts use the selection set; they are not confirmatory evidence.

| Source | Family | Shared candidate | I0 CRPS | I1 CRPS | I1−I0 |
|---|---|---:|---:|---:|---:|
| weibo | hurdle | 0 | 144.698345 | 141.449938 | -3.248408 |
| weibo | qrf | 3 | 112.750741 | 111.154537 | -1.596204 |
| weibo | ngboost | 0 | 129.752589 | 129.003222 | -0.749367 |
| seismic | hurdle | 3 | 52.652305 | 45.031473 | -7.620832 |
| seismic | qrf | 3 | 43.697723 | 39.353283 | -4.344440 |
| seismic | ngboost | 3 | 43.479731 | 39.463399 | -4.016332 |

See MODEL_LOCK.json for exact model hashes. No refit on TRAIN+VALIDATION is performed.
The six-comparison multiplicity family remains fixed, including unavailable slots.
CASPER remains unsupported under the archived wrapper and budget; no comparison to its published accuracy is asserted.
