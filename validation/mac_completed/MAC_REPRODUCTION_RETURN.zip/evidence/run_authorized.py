"""Finite audit orchestration. Never removes locks or repeats a stage."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,datetime,time
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
CTRL=Path('/Users/fahad/Downloads/BRACE_Original_Reproduction_Controller')
PYTHON=ROOT/'BRACE-Phase13C-20260912/.venv/bin/python'
WORK=ROOT/'REPRO_ORIGINALS_20260921'
ASSETS=ROOT/'ORIGINALS_EXPORT_20260914T074651Z'
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
ENV=os.environ.copy();ENV.update(PYTHONDONTWRITEBYTECODE='1',MPLCONFIGDIR=str(BASE/'cache/matplotlib'),XDG_CACHE_HOME=str(BASE/'cache'),NUMBA_CACHE_DIR=str(BASE/'cache/numba'))
(BASE/'cache').mkdir(exist_ok=True)
state={'start_utc':now(),'controller':str(CTRL),'python':str(PYTHON),'work':str(WORK),'stages':[],'source_policy':'No original changes; no lock removal; each authorized scientific stage at most once','refit_to_test_chain':False}
write(BASE/'SESSION_STATE.json',state)
def run(stage,out=None):
 args=[str(PYTHON),'-B',str(CTRL/'reproduce.py'),stage,'--work',str(WORK)]
 if stage=='restore':args+=['--assets',str(ASSETS)]
 if out:args+=['--out',str(out)]
 row={'stage':stage,'argv':args,'cwd':str(ROOT),'start_utc':now(),'out':str(out) if out else None,'status':'running','environment_overrides':{k:ENV[k] for k in ['PYTHONDONTWRITEBYTECODE','MPLCONFIGDIR','XDG_CACHE_HOME','NUMBA_CACHE_DIR']}}
 state['stages'].append(row);write(BASE/'SESSION_STATE.json',state)
 with (BASE/(stage+'.console.log')).open('x') as f:
  p=subprocess.run(args,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT)
 row.update(returncode=p.returncode,end_utc=now(),status='process_completed')
 if out and (out/'RUN_REPORT.json').is_file():row['run_report']=json.loads((out/'RUN_REPORT.json').read_text())
 write(BASE/'SESSION_STATE.json',state);print(stage,p.returncode,flush=True)
 return p.returncode
try:
 manifest=json.loads((CTRL/'CONTROLLER_MANIFEST.json').read_text());verification=[]
 for name,expect in manifest.items():
  rel=Path(name)
  if rel.is_absolute() or '..' in rel.parts or any(x.lower()=='old' for x in rel.parts):raise RuntimeError('Unsafe controller manifest name')
  p=CTRL/rel
  if p.is_symlink() or not p.resolve().is_relative_to(CTRL):raise RuntimeError('Unsafe controller path')
  observed={'bytes':p.stat().st_size,'sha256':sha(p)}
  verification.append({'path':name,'expected':expect,'observed':observed,'matched':observed==expect})
 write(BASE/'CONTROLLER_VERIFICATION.json',verification)
 if not all(x['matched'] for x in verification):raise RuntimeError('Controller manifest mismatch; no stage launched')
 (BASE/'control_evidence').mkdir()
 for name in ['README_AR.md','CODEX_MAC_TASK_AR.md','reproduce.py','CONTROLLER_MANIFEST.json','DISTRIBUTION_INDEX.json','VALIDATION_AR.md']:(BASE/'control_evidence'/name).write_bytes((CTRL/name).read_bytes())
 if not PYTHON.exists():raise RuntimeError('Historical interpreter absent; independent pinned environment required')
 if run('verify' if WORK.exists() else 'restore')!=0:raise RuntimeError('Restore/verify failed')
 if run('environment')!=0:raise RuntimeError('Environment command failed')
 env=json.loads((BASE/'environment.console.log').read_text());write(BASE/'ENVIRONMENT_CHECK.json',env)
 if not env.get('passed'):raise RuntimeError('Historical environment mismatch; do not relax requirements')
 if run('check-all',BASE/'check_all')!=0:raise RuntimeError('check-all failed; training not authorized past this gate')
 # Independently frozen-parent stages; a failure never triggers retry.
 for stage in ['train','test','noise']:run(stage,BASE/stage)
 state['status']='stages_attempted_requires_scientific_review'
except BaseException as e:
 state['status']='stopped';state['stop_reason']=str(e);print(type(e).__name__,str(e),flush=True)
finally:
 state['end_utc']=now();write(BASE/'SESSION_STATE.json',state)
